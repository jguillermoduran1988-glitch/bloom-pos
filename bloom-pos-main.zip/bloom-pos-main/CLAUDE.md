# Bloom POS — Contexto del proyecto para Claude

> **INSTRUCCIÓN PARA CLAUDE:** Lee este archivo al inicio de cada conversación. Al final de cada sesión, o cuando se haga un cambio importante, actualiza este archivo con lo que se hizo. Mantén el historial de cambios al final.

---

## ¿Qué es este proyecto?

**Bloom POS** es una aplicación web PWA para una tienda de ropa de baño (Bloom). Combina:
- **CRM de WhatsApp** — gestión de chats con clientes, embudos de venta, etiquetas
- **POS (Punto de Venta)** — ventas, carrito, medios de pago, integración Shopify
- **Chat interno de equipo** — mensajería interna entre vendedoras
- **Estadísticas** — ventas por vendedor, canal, historial, cambios/garantías
- **Etiquetas de precio** — generador de etiquetas para imprimir (1.25x1 pulg)

---

## Stack técnico

| Componente | Tecnología |
|-----------|-----------|
| Frontend | HTML + JavaScript vanilla (sin frameworks) |
| Backend API | Cloudflare Worker (`worker.js`) |
| DB chat clientes | Cloudflare D1 (`bloom-wa`, binding `env.bloom_wa`) |
| DB resto del negocio | Supabase (PostgreSQL) |
| Hosting frontend | Cloudflare Pages (auto-deploy desde GitHub main) |
| Almacenamiento archivos | Supabase Storage (bucket `team-chat`) |
| Push notifications | Worker separado (`bloom-push`) |

---

## URLs importantes

| Servicio | URL |
|---------|-----|
| App (frontend) | https://bloom-dashboard-b1j.pages.dev |
| Worker API (backend) | https://bloomchat.jguillermoduran1988.workers.dev |
| Worker push | https://bloom-push.jguillermoduran1988.workers.dev |
| Supabase proyecto | https://qojehszkcuggmjxefvnv.supabase.co |
| Repositorio GitHub | https://github.com/jguillermoduran1988-glitch/bloom-pos |

---

## Archivos principales

| Archivo | Qué hace |
|---------|---------|
| `index.html` | Toda la UI — pantallas, modales, estilos CSS inline |
| `app.js` | Toda la lógica del frontend (~4300 líneas) |
| `worker.js` | Backend Cloudflare: webhook WhatsApp, envío mensajes, integración Shopify/Alegra |
| `config.js` | Configuración pública (URLs, clave anon Supabase, productos demo) |
| `sw.js` | Service Worker PWA — cache de assets |
| `colombia.js` | Datos de departamentos y ciudades de Colombia |

---

## Cómo desplegar

- **Frontend:** cualquier `git push origin main` desde `C:\Users\Usuario\bloom-pos` dispara auto-deploy en Cloudflare Pages automáticamente. No se necesita hacer nada más.
- **Worker backend:** requiere `wrangler deploy` manual desde la carpeta del proyecto (necesita credenciales Cloudflare).

**Carpeta de trabajo local:** `C:\Users\Usuario\bloom-pos`

---

## Cloudflare D1 — Chat de clientes (WhatsApp CRM)

Base de datos: `bloom-wa` (id: `9f398288-159e-46e5-9ebf-8ff290155d14`)

| Tabla | Contenido |
|-------|-----------|
| `wa_conversations` | Conversaciones WhatsApp (id=phone, stage, pipeline_id, last_message, etc.) |
| `wa_messages` | Mensajes de cada chat (id, conversation_id, direction, type, body, media_url, status, ts) |
| `wa_contacts` | Contactos WhatsApp (phone, name, email, avatar, tags) |

### Columnas clave de `wa_messages`
- `type` → `"text"` / `"image"` / `"audio"` / `"note"` (nota interna vendedor)
- `direction` → `"outbound"` / `"inbound"`
- `media_url` → URL pública del archivo en Supabase Storage
- `ts` → timestamp ISO

### Endpoints del Worker para chat de clientes
- `GET /wa/conversations` → lista conversaciones
- `GET /wa/conversations/:id/messages` → mensajes de una conversación
- `POST /wa/send` → enviar mensaje (texto, foto, audio, nota). Body: `{ conversation_id, phone, body, media_url, type }`
- `POST /wa/conversations/:id/read` → marcar como leído
- `PATCH /wa/conversations/:id` → actualizar stage, pipeline_id
- `PATCH /wa/contacts/:phone` → actualizar tags

### IMPORTANTE: Todo el chat de clientes va a D1 vía Worker
**NO usar `sbPost("messages", ...)` para el chat de clientes.** La tabla `messages` de Supabase ya no se usa para eso. Fotos, audios, texto y notas internas del chat de clientes se guardan todos con `POST /wa/send`.

---

## Supabase — Resto del negocio

| Tabla | Contenido |
|-------|-----------|
| `pipelines` | Embudos de venta (name, stages[], store) |
| `sales` | Ventas del POS |
| `sellers` / `users` | Vendedoras y cajeras |
| `pos_settings` | Config del POS: `shopify_draft`, `goal_plans`, `label_presets`, recibo |
| `team_messages` | Mensajes del chat interno de **equipo** (sí usa Supabase) |
| `exchanges` | Cambios y garantías |
| `customers` | Clientes registrados en el POS |
| `custom_orders` | Pedidos personalizados |

### Datos importantes guardados en `pos_settings`
- `goal_plans` → meta de ventas mensual + distribución por día (NO en localStorage)
- `label_presets` → plantillas de etiquetas de precio guardadas (NO en localStorage)

---

## Pantallas de la app (navegación inferior)

1. **Chats** — CRM WhatsApp con embudos, etiquetas, panel de cliente
2. **POS** — punto de venta con carrito, medios de pago, cajero/vendedor
3. **Equipo** — chat interno del equipo con fotos y notas de voz
4. **Datos** — estadísticas: Tienda, Ventas, Clientes, Personalizados, Cambios, Etiquetas
5. **Config** — ajustes: usuarios, pagos, Shopify, recibo, meta de ventas

---

## Reglas importantes al hacer cambios

1. **Siempre probar sintaxis JS** antes de commitear: `node --check app.js`
2. **No usar `await` en funciones no-async** — rompe todo el archivo JS
3. **El frontend lo sirve Cloudflare Pages**, no el Worker. Son cosas separadas.
4. **`pos_settings` en Supabase** guarda goal_plans y label_presets — no localStorage
5. **Al cambiar SW cache** subir el número de versión (`bloom-v91`, `bloom-v92`, etc.)
6. **Commitear desde** `C:\Users\Usuario\bloom-pos` y hacer push a `origin main`
7. **Chat de clientes → D1/Worker. Chat de equipo → Supabase.** No mezclar.
8. **Archivos (fotos/audio)** siempre se suben a Supabase Storage (`team-chat` bucket) con `sbUpload()`. La URL resultante se guarda en D1 (para chat clientes) o Supabase (para chat equipo).
9. **Para migrar columnas en D1:** `npx wrangler d1 execute bloom-wa --remote --command "ALTER TABLE ..."`

---

## Historial de sesiones con Claude

### 2026-06-29
- Se agregó plus menu al chat de clientes (emoji, foto, nota de voz) — igual al chat de equipo
- Se descubrió que el chat de clientes usa D1/Worker, NO Supabase — se corrigió todo para usar `POST /wa/send`
- `attachChatPhoto`, `toggleChatVoice` y `addNote` ahora guardan en D1 vía `/wa/send`
- Worker `/wa/send` actualizado para aceptar `media_url` y `type` (image/audio/note/text)
- La columna `media_url` ya existía en `wa_messages` de D1
- Chat de equipo (pestaña Equipo) sigue en Supabase (`team_messages`) — eso está correcto
- Archivos (fotos/audio) se suben a Supabase Storage y la URL se guarda en D1
- SW cache en `bloom-v91`

### 2026-06-30 — Sesión 2 (tarde)

#### Fix: cliente no se vinculaba al pedido POS en Shopify
- **Causa raíz 1**: `findOrCreateShopifyCustomer` enviaba `addresses` con `province: "Atlántico"` (nombre); Shopify espera código ISO → 422 → creación fallaba silenciosamente → `null`
- **Causa raíz 2**: La búsqueda usaba `customers/search.json` (fuzzy, poco confiable); cambiado a `customers.json?email=xxx` y `customers.json?phone=+57xxx` (lookup exacto)
- **Causa raíz 3**: Fallback en `createShopifyOrder` usaba `phone` sin prefijo E.164 → Shopify lo ignoraba
- **Fix aplicado**: eliminados `addresses` de creación, lookup exacto por email/teléfono, retry en 422, phone formateado como `+57XXXXXXXXXX`, actualización de nombre siempre al encontrar cliente existente
- El Worker requiere deploy manual en Cloudflare (`worker.js` actualizado en GitHub)

#### Feat: borrar cliente desde Datos → Clientes
- Botón **🗑 Borrar** en el footer del modal de editar cliente (estilo `.modal-del`, rojo suave)
- Pide confirmación; si el cliente tiene compras avisa cuántas y aclara que las ventas NO se borran
- Las ventas en `sales` usan columnas planas (customer_name, email, etc.) — no hay FK, borrar cliente no afecta historial

#### Limpieza ventas de prueba (2026-06-30)
- Eliminadas 9 ventas de prueba de Supabase (D11–D19, clientes Lina Narvaez y Guillermo Duran)
- Draft orders D11–D19 en Shopify pendientes de borrar manualmente (Shopify admin → Pedidos preliminares)

#### Fix pedidos POS en Shopify
- `fulfillment_status: "fulfilled"` para todos los pedidos POS (no solo tienda)
- `tax_lines` con IVA 19% (`precio × 19/119`) en cada line_item — Shopify no lo calcula automáticamente en pedidos creados por API
- `price` explícito en items con `variant_id` — sin esto Shopify usa el precio de catálogo actual, no el precio cobrado

#### Fix módulo de cambios (Datos → Cambios)
- Precio de reembolso ahora usa el `total` pagado real (proporcional), no el precio de catálogo del item
- Worker retorna error claro si el pedido no existe en Shopify (antes daba "Not Found" críptico)
- Ventas creadas como draft order antiguas no se pueden cambiar desde el módulo (Shopify no las tiene como pedidos reales)

#### Fix WhatsApp webhook — migración D1 pendiente
- **Síntoma**: mensajes de WhatsApp no llegaban, error en logs: `D1_ERROR: no such column: last_direction: SQLITE_ERROR`
- **Causa**: el worker usaba la columna `last_direction` en `wa_conversations` pero nunca se había ejecutado la migración
- **Fix**: ejecutar vía API de Cloudflare D1:
  ```sql
  ALTER TABLE wa_conversations ADD COLUMN last_direction TEXT DEFAULT 'outbound'
  ```
- **Lección**: cada vez que el worker use una columna nueva en D1, ejecutar la migración ANTES de desplegar el worker
- Se puede ejecutar con el token Cloudflare guardado en memoria (`reference_cloudflare_token.md`)

---

### 2026-06-30 — Sesión 1 (mañana) — Lo que SE HIZO (funciona)

#### Borde completo en conversaciones asignadas
- `.chat-item.my-conv` y `.kb-card.my-conv`: ahora tienen `outline:2px solid var(--accent)` en los 4 lados (antes era solo borde izquierdo + fondo)
- Se eliminó el fondo `rgba` de los ítems asignados
- Kanban cards también muestran el borde dorado si `c.assigned_to === pos.currentUser.name`

#### Múltiples features de sesiones anteriores (ya en producción)
- **Panel cliente**: título "Datos cliente", muestra dirección, historial de compras con fechas
- **Auto-tag "recompra"**: se agrega automáticamente si el cliente tiene compras; configurable en Config Chat
- **Colores de etapa**: selector de color en el editor de embudos (`stage_colors` JSONB en Supabase `pipelines`)
- **Automatización seguimiento**: sección en Config Chat con reglas (embudo+etapa+tiempo+mensaje), Worker corre cada hora
- **Selector de etiquetas**: dropdown con etiquetas conocidas + crear nueva, reemplazó el input de texto
- **Productos**: abre inmediatamente con "Cargando…" mientras carga, luego muestra resultados
- **`sizes` en Worker**: `fetchShopify()` ahora computa el campo `sizes` por producto

#### Pendiente de migración en BD (NO ejecutados aún)
- Supabase: `ALTER TABLE pipelines ADD COLUMN IF NOT EXISTS stage_colors jsonb DEFAULT '{}';`
- Supabase: `ALTER TABLE pos_settings ADD COLUMN IF NOT EXISTS chat_config jsonb DEFAULT '{}';`
- D1: `ALTER TABLE wa_conversations ADD COLUMN IF NOT EXISTS last_direction TEXT DEFAULT 'outbound';`
- Worker: `npx wrangler deploy` (para el cron de seguimiento automático)

---

### 2026-06-30 — Bugs PENDIENTES (no resueltos)

#### 🔴 BUG 1: Kanban en móvil — botones del header desaparecen

**Síntoma**: Al abrir el kanban y luego cerrarlo (tocando el mismo botón de tablero), los 3 botones que aparecen junto al logo de Bloom (tablero, POS, datos + "en línea") desaparecen. Solo queda el logo. Para recuperarlos hay que recargar la app.

**Lo que debería verse**: Logo Bloom a la izquierda + botón kanban + botón POS + botón Datos + punto "en línea" a la derecha del logo. (El usuario envió screenshot de referencia mostrando el estado correcto.)

**Intentos fallidos**:
1. Quitar `chat-open` en `toggleBoardView()` → falló
2. `switchScreen` cierra kanban → falló
3. `body.board-open` + CSS `position:fixed` → falló
4. `history.pushState` + listener `popstate` → falló
5. `style.cssText` directo en JS para mostrar/ocultar sidebar y board → falló
6. CSS classes `.kb-show` / `.kb-hidden` con `!important` → último intento, aún no confirmado por el usuario

**Estado actual del código** (app.js ~línea 126):
```javascript
function _closeBoardMobile(){
  $("#kanbanBoard")?.classList.remove("kb-show");
  document.querySelector(".sidebar")?.classList.remove("kb-hidden");
  document.body.classList.remove("board-open","chat-open","panel-open");
  state.active=null;
  const pan=$("#panel"); if(pan) pan.classList.add("hidden");
}
function toggleBoardView(){
  _boardMode=!_boardMode;
  if(window.innerWidth<=720){
    if(_boardMode){
      document.querySelector(".sidebar")?.classList.add("kb-hidden");
      $("#kanbanBoard")?.classList.add("kb-show");
      document.body.classList.add("board-open");
      history.pushState({kanban:true},"");
    } else { _closeBoardMobile(); }
  } else {
    $("#kanbanBoard").classList.toggle("show",_boardMode);
  }
  if(_boardMode) renderBoard();
}
```

**CSS actual** (index.html ~línea 176):
```css
@media(max-width:720px){
  .sidebar.kb-hidden{display:none!important;visibility:hidden!important}
  #kanbanBoard.kb-show{display:flex!important;position:fixed!important;top:0;left:0;right:0;bottom:56px;z-index:90;overflow:hidden;flex-direction:column;background:var(--bg)}
}
```

**Hipótesis pendiente de investigar**: Los botones están en `.side-head` > `div` (segundo hijo). El sidebar sí aparece (logo, tabs, búsqueda, lista de chats), pero SOLO el div de botones desaparece. Esto sugiere que NO es un problema de display del sidebar completo, sino algo específico con ese div de botones. Posibles causas: (a) algún JS toca `.side-head` o su segundo hijo; (b) problema de compositing/z-index de iOS Safari con el elemento que estuvo en `position:fixed`; (c) el `#kanbanBoard` con `position:absolute;inset:0;z-index:20` (su estado CSS por defecto) cubre el header aunque tenga `display:none` de alguna forma.

**Siguiente paso sugerido**: Buscar si hay algún JS que modifique `.side-head` o el div de los botones. Considerar mover `#kanbanBoard` fuera de `#screen-chats` en el HTML (hacerlo hijo directo de `<body>`) para que `position:absolute;inset:0` no afecte el layout del grid.

---

#### 🔴 BUG 2: Selector de productos Shopify — no carga en escritorio, se cierra en móvil

**Síntoma**:
- **Escritorio (desktop)**: Al tocar "Productos" en las acciones de la ficha de cliente, el modal se abre con "Cargando productos…" pero nunca muestra los productos.
- **Móvil**: El modal se abre pero "se cierra" (el usuario lo percibe así — puede ser que se cierre solo, o que quede vacío/inutilizable).

**Lo que se sabe**:
- El endpoint del Worker `GET /products?store=bloom` SÍ funciona y devuelve 600 productos (313 con stock > 0).
- CORS está configurado (`Access-Control-Allow-Origin: *`) y funciona para todos los demás endpoints.
- El Service Worker NO intercepta peticiones a `workers.dev` (excluido explícitamente en sw.js línea 17).
- `fetchProducts()` hace `fetch(WORKER_URL/products?store=bloom)` — si esto cuelga en el browser, nunca resuelve.

**Último estado del código** (app.js ~línea 1186):
```javascript
async function openPicker(){
  // muestra caché local primero si existe
  // luego fetchProducts() con AbortController de 14s timeout
  // si falla, usa caché o DEMO_PRODUCTS
}
```

**Hipótesis**: Puede ser que la primera vez (sin caché local) el fetch al Worker desde el browser tarda demasiado o falla silenciosamente. En móvil, el usuario puede estar cerrando el modal manualmente al ver que está vacío/cargando.

**Siguiente paso sugerido**: Agregar un mensaje de error visible si fetchProducts() no resuelve en tiempo. También vale verificar desde el browser (DevTools > Network) si la petición a /products realmente llega al Worker o se queda pendiente.

---

## Reglas importantes al hacer cambios
